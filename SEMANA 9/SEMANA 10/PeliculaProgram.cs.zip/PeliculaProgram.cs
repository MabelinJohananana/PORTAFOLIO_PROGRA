﻿// See https://aka.ms/new-console-template for more information
namespace peli
{

    public class peli
    {
        string nombre;
        double duracion;
        string genero;
        int año;
        double clas;
        bool dura;

        public void boll(double a)
        {
            if (a >= 3)
            {
                dura = true;
                Console.WriteLine("La pélicula sera éica");
            }
            else
            {
                Console.WriteLine("La pelicula no sera tan épica");
            }


        }
        public void clasi()
        {
            if (clas >= 0 && clas <= 2)
            {
                Console.WriteLine("Muy mala");
            }
            if (clas > 2 && clas <= 5)
            {
                Console.WriteLine("Mala");
            }
            if (clas > 5 && clas <= 7)
            {
                Console.WriteLine("Regular");
            }
            if (clas > 7 && clas <= 8)
            {
                Console.WriteLine("Buena");
            }
            if (clas > 8 && clas <= 10)
            {
                Console.WriteLine("Excelente");
            }

        }
        public void mostra()
        {
            String texto = $"Nombre: {nombre}, Género: {genero}, Duración: {duracion}, Año: {año} Clasificacíon:";
            Console.WriteLine(texto);
        }
        public peli(string o, string e, double a, double d, int ano)
        {
            nombre = o;
            genero = e;
            duracion = d;
            año = ano;
            clas = a;
            dura = false;

        }

        static void Main()
        {
            Console.WriteLine("Ingrese el nombre de la pelicula");
            string no = Console.ReadLine();
            Console.WriteLine("Ingrese la duración de la pelicula");
            double du = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Ingrese el año de la pelicula");
            int ano = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Ingrese el genero de la pelicula");
            string ge = Console.ReadLine();
            Console.WriteLine("Ingrese la valoración de la pelicula");
            double cla = Convert.ToDouble(Console.ReadLine());

            peli pelicula = new peli(no, ge, cla, du, ano);


            pelicula.mostra();
            pelicula.clasi();
            pelicula.boll(du);
            Console.ReadKey();

        }
    }
}
